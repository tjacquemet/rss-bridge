<?php
require_once('Shimmie2Bridge.php');

class Rule34pahealBridge extends Shimmie2Bridge {

	const MAINTAINER = 'mitsukarenai';
	const NAME = 'Rule34paheal';
	const URI = 'http://rule34.paheal.net/';
	const DESCRIPTION = 'Returns images from given page';
}
